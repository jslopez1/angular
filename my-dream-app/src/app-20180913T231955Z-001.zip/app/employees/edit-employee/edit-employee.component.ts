import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeesService } from '../../services/employees.service';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {
  name: string;
  age: number;
  charge: string;
  state: string;
  id: number;
  employee: {name: string, age: number, charge: string, state: string};
  constructor(private route: ActivatedRoute, private employeesService: EmployeesService, private router: Router) { }

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    this.id = id;
    this.employee = this.employeesService.getEmployee(+id);
    this.name = this.employee.name;
    this.age = this.employee.age;
    this.charge = this.employee.charge;
    this.state = this.employee.state;
  }

  saveChanges() {
    this.employeesService.setEmployee(this.id, {
      name: this.name,
      age: this.age,
      charge: this.charge,
      state: this.state
    });
    this.router.navigate(['../'], {relativeTo: this.route});
  }

}
