import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { EmployeesService } from '../../services/employees.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employee: {name: string, age: number, charge: string, state: string};
  constructor(private route: ActivatedRoute, private employeesService: EmployeesService, private router: Router) { }

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    this.employee = this.employeesService.getEmployee(+id);
    this.route.params.subscribe(
      (params: Params) => {
        this.employee = this.employeesService.getEmployee(+params['id']);
      }
    );
  }

  onEdit() {
    this.router.navigate(['edit'], {relativeTo: this.route});
  }

}
