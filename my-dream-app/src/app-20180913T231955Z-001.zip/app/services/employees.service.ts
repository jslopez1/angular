export class EmployeesService {
    employees = [{
        name: 'pepito',
        age: 30,
        charge: 'Engineer',
        state: 'active'
    }, {
        name: 'juanito',
        age: 28,
        charge: 'Manager',
        state: 'active'
    }];
    getEmployee(id: number) {
        return this.employees[id];
    }

    setEmployee(id: number,  employee: {name: string, age: number, charge: string, state: string}) {
        this.employees[id] = employee;
    }
}